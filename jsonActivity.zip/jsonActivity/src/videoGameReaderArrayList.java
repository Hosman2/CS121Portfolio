import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class videoGameReaderArrayList {
    public static void main(String[] args) {
        try{
            Gson gson = new Gson();
            BufferedReader reader = new BufferedReader(new FileReader("videoGames.json"));

            //videoGame videoGameInfo = gson.fromJson(reader, videoGame.class);
            Type videoGameArrayList = new TypeToken<ArrayList<videoGame>>(){}.getType();

            ArrayList<videoGame> videoGameList = gson.fromJson(reader, videoGameArrayList);
            System.out.println("***************** Video Game Details ********************");
            for (videoGame videoGameInfo: videoGameList) {
                System.out.printf("Name: %s%nType: %s%nReleased: %d%n", videoGameInfo.getName(), videoGameInfo.getType(), videoGameInfo.getReleased());
                System.out.println("-------------------\n\n");
            }
        }catch(IOException e){
            e.printStackTrace();

        }

    }
}
