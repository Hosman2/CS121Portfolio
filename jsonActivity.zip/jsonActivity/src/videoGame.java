public class videoGame {
    private String name, type;

    private int released;

    private static int instanceCount = 0;


    videoGame(){
        instanceCount++;
    }

    videoGame(String name, String type){
        this.name = name;
        this.type = type;
        instanceCount++;
    }
    videoGame(String name, String type, int released){
        this.name = name;
        this.type = type;
        this.released = released;
        instanceCount++;
    }
    videoGame(int released){
        this.released = released;
        instanceCount++;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setType(String type){
        this.type = type;
    }
    public void setReleased(int released){
        this.released = released;
    }

    public String getName(){
        return name;
    }
    public String getType(){
        return type;
    }
    public int getReleased(){
        return released;
    }

    public String showDetails(){
        return String.format("Name: %s%nType: %s%nReleased: %d%d", name, type, released);
    }
    public static int getInstanceCount(){
        return instanceCount;
    }
}
