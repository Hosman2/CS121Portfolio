import com.google.gson.Gson;

import java.io.FileWriter;
import java.io.IOException;

public class videoGameWriter {
    public static void main(String[] args) {


    try{
        videoGame videoGameInfo = new videoGame("Terraria", "Survival", 2011);
        Gson gson = new Gson();
        String jsonString = gson.toJson(videoGameInfo);
        System.out.println(jsonString);
        FileWriter filewrite = new FileWriter("videoGame.json");
        filewrite.write(jsonString);
        filewrite.close();
    }catch(IOException e){
        e.printStackTrace();
    }
}
}
