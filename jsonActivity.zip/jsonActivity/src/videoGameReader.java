import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class videoGameReader {
    public static void main(String[] args) {
        try{
            Gson gson = new Gson();
            BufferedReader reader = new BufferedReader(new FileReader("videoGame.json"));

            videoGame videoGameInfo = gson.fromJson(reader, videoGame.class);
            System.out.println("***************** Video Game Details ********************");
            System.out.printf("Name: %s%nType: %s%nReleased: %d%n", videoGameInfo.getName(), videoGameInfo.getType(), videoGameInfo.getReleased());
        }catch(IOException e){
            e.printStackTrace();

        }
    }
}
