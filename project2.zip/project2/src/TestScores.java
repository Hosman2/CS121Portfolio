import java.util.Random;
import java.util.Scanner;

public class TestScores {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random rand = new Random();
        final int SIZE = rand.nextInt(3, 10);
        int[] testScores = new int[SIZE];
        char[] letterGrades = new char[SIZE];
        System.out.printf("Enter your %d test scores\n", SIZE);

        for (int i = 0; i < SIZE; i++) {
            System.out.printf("Enter test %d score:", i + 1);
            testScores[i] = scanner.nextInt();
        }
        for (int i = 0; i < SIZE; i++) {
            letterGrades[i] = getLetterGrade(testScores[i]);

        }
        printGrades(testScores, letterGrades);
        printHighestScore(testScores);
        printLowestScore(testScores);
        printAverageScore(testScores);
    }

    public static char getLetterGrade(int score) {
        if (score >= 90) {
            return 'A';
        } else if (score >= 80 && score <= 89) {
            return 'B';
        } else if (score >= 70 && score <= 79) {
            return 'C';
        } else if (score >= 60 && score <= 69) {
            return 'D';
        } else if (score <= 59){
            return 'F';
        }else{
            return 'N';
        }

    }
    public static void printGrades(int [] testScores, char [] letterGrades){
        System.out.println("Score        Grade");
        for(int i = 0; i < testScores.length; i++){
            System.out.printf(" %-14d%c\n", testScores[i], letterGrades[i]);
        }

    }
    public static void printHighestScore(int[] testScores){
        int highestScore = testScores[0];
        for(int i = 0; i < testScores.length; i++){
            if(testScores[i] > highestScore){
                highestScore = testScores[i];
            }
        }
        System.out.printf("The highest test score is %d\n", highestScore);
    }
    public static void printLowestScore(int[] testScores){
        int lowestScore = testScores[0];
        for(int i = 0; i < testScores.length; i++) {
            if (testScores[i] < lowestScore) {
                lowestScore = testScores[i];
            }
        }
        System.out.printf("The lowest test score is %d\n", lowestScore);
    }
    public static void printAverageScore(int[] testScores){
        int length = testScores.length;
        int sum = 0;
        for(int i = 0; i < testScores.length; i++) {
            sum += testScores[i];
        }
        double avg = (double)sum / length;
        System.out.printf("The average test score is %.2f\n", avg);
    }

}